export { XLSXService } from './xlsx.service';
export declare class XLSXModule {
}
