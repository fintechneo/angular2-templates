import { NgZone } from '@angular/core';
import { AsyncSubject } from 'rxjs/AsyncSubject';
import { Observable } from 'rxjs/Observable';
import { CanvasTableComponent } from '../canvastable/canvastable.component';
export declare class XLSXService {
    private ngZone;
    scriptLoadedSubject: AsyncSubject<any>;
    xlsx: any;
    scriptLocation: string;
    constructor(ngZone: NgZone);
    private loadScripts();
    getXLSX(): Observable<any>;
    getCellRef(colIndex: number, rowIndex: number): any;
    parse(arraybuffer: ArrayBuffer): Observable<any>;
    writeAndDownload(filename: string, wb: any): void;
    exportCanvasTableToExcel(canvastable: CanvasTableComponent, sheetname: string): void;
}
