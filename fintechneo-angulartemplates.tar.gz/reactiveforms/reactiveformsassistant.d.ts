import { AbstractControl, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { Subject } from 'rxjs/Subject';
/**
 * Change notifications are sent with this class containing a string array for the
 * object path and the changed value.
 */
export declare class FormUpdateEvent {
    path: string[];
    value: any;
    constructor(path: string[], value: any);
    applyToObject(targetObject: any): void;
}
/**
 * Helper service for receiving change notifications on individual form controls
 */
export declare class ReactiveFormAssistant {
    private formBuilder;
    formGroup: FormGroup;
    formArrayPaths: string[][];
    formUpdatesSubject: Subject<FormUpdateEvent>;
    constructor(formBuilder: FormBuilder);
    cloneRow(rowctrl: AbstractControl): AbstractControl;
    findControlByPath(path: string[]): AbstractControl;
    removeRowFromFormArray(formArray: FormArray, rowindex: number, notify?: boolean): void;
    addRowToFormArray(formArray: FormArray, rowdata?: any, notify?: boolean): void;
    /**
     * Send full array update (useful when reordering)
     * @param formArray
     */
    sendFullArray(formArray: FormArray): void;
    patchFormUpdateEvent(msg: FormUpdateEvent): void;
    controlsubscribe(control?: AbstractControl, path?: string[]): void;
}
