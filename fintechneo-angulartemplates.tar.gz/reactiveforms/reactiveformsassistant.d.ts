import { AbstractControl, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { Subject } from 'rxjs/Subject';
/**
 * Change notifications are sent with this class containing a string array for the
 * object path and the changed value.
 */
export declare class FormUpdateEvent {
    path: string[];
    value: any;
    constructor(path: string[], value: any);
    applyToObject(targetObject: any): void;
}
/**
 * Helper service for receiving realtime change notifications on individual form controls
 *
 * This service is of no use outside the component lifecycle so it can be provided directly
 * on the component (add to providers array of the @Component decorator)
 *
 * Start by setting the formGroup property to the formGroup of your component. Then call
 * controlSubscribe() to add value change listeners to all the form controls.
 *
 * A dataservice should subscribe to formUpdatesSubject to listen for changes made by the user,
 * and use patchFormUpdateEvent to patch the form with changes coming from the backend.
 *
 *
 */
export declare class ReactiveFormAssistant {
    private formBuilder;
    formGroup: FormGroup;
    formArrayPaths: string[][];
    /**
     * A dataservice should subscribe to this subject to get changes made by the front-end user
     * and pass on these to the backend server.
     */
    formUpdatesSubject: Subject<FormUpdateEvent>;
    constructor(formBuilder: FormBuilder);
    cloneRow(rowctrl: AbstractControl): AbstractControl;
    findControlByPath(path: string[]): AbstractControl;
    removeRowFromFormArray(formArray: FormArray, rowindex: number, notify?: boolean): void;
    addRowToFormArray(formArray: FormArray, rowdata?: any, notify?: boolean): void;
    /**
     * Send full array update (useful when reordering)
     * @param formArray
     */
    sendFullArray(formArray: FormArray): void;
    /**
     * A dataservice receiving realtime FormUpdateEvent messages from the backend should call this
     * method to apply changes to the form
     *
     * @param msg
     */
    patchFormUpdateEvent(msg: FormUpdateEvent): void;
    controlsubscribe(control?: AbstractControl, path?: string[]): void;
}
