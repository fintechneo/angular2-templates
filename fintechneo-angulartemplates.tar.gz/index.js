export { CanvasTableComponent, CanvasTableContainerComponent, AnimationFrameThrottler, CanvasTableModule } from './canvastable/canvastable.module';
//# sourceMappingURL=index.js.map