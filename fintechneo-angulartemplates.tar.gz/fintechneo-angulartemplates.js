import { Component, ElementRef, EventEmitter, Injectable, Input, NgModule, NgZone, Output, Renderer, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule, MatTooltip, MatTooltipModule } from '@angular/material';
import { BehaviorSubject as BehaviorSubject$1 } from 'rxjs/BehaviorSubject';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Subject as Subject$1 } from 'rxjs/Subject';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/*
 *  Copyright 2010-2016 FinTech Neo AS ( fintechneo.com )- All rights reserved
 */
var AnimationFrameThrottler = (function () {
    function AnimationFrameThrottler(taskkey, task) {
        this.taskkey = taskkey;
        this.task = task;
        if (!AnimationFrameThrottler.taskMap) {
            AnimationFrameThrottler.mainLoop();
        }
        AnimationFrameThrottler.taskMap[taskkey] = task;
        AnimationFrameThrottler.hasChanges = true;
    }
    /**
     * @return {?}
     */
    AnimationFrameThrottler.mainLoop = /**
     * @return {?}
     */
    function () {
        AnimationFrameThrottler.taskMap = {};
        var /** @type {?} */ mainLoop = function () {
            if (AnimationFrameThrottler.hasChanges) {
                AnimationFrameThrottler.hasChanges = false;
                Object.keys(AnimationFrameThrottler.taskMap).forEach(function (key) {
                    AnimationFrameThrottler.taskMap[key]();
                    delete AnimationFrameThrottler.taskMap[key];
                });
            }
            window.requestAnimationFrame(function () { return mainLoop(); });
        };
        window.requestAnimationFrame(function () { return mainLoop(); });
    };
    AnimationFrameThrottler.taskMap = null;
    AnimationFrameThrottler.hasChanges = false;
    return AnimationFrameThrottler;
}());
/**
 * @record
 */

/**
 * @record
 */

var FloatingTooltip = (function () {
    function FloatingTooltip(top, left, width, height, tooltipText) {
        this.top = top;
        this.left = left;
        this.width = width;
        this.height = height;
        this.tooltipText = tooltipText;
    }
    return FloatingTooltip;
}());
var CanvasTableColumnSection = (function () {
    function CanvasTableColumnSection(columnSectionName, width, leftPos, backgroundColor) {
        this.columnSectionName = columnSectionName;
        this.width = width;
        this.leftPos = leftPos;
        this.backgroundColor = backgroundColor;
    }
    return CanvasTableColumnSection;
}());
var CanvasTableComponent = (function () {
    function CanvasTableComponent(elementRef, renderer, _ngZone) {
        //this.elementId = "canvasTable"+(CanvasTableComponent.incrementalId++);
        //console.log("Creating canvas table with id "+this.elementId);
        this.renderer = renderer;
        this._ngZone = _ngZone;
        this._topindex = 0.0;
        this._rowheight = 30;
        this.fontheight = 16;
        this.fontFamily = 'Roboto, "Helvetica Neue", sans-serif';
        this.scrollbardrag = false;
        this._horizScroll = 0;
        this._rows = [];
        this._columns = [];
        this.hoverRowColor = "rgba(0, 0, 0, 0.04)";
        this.selectedRowColor = "rgba(225, 238, 255, 1)";
        this.colpaddingleft = 10;
        this.colpaddingright = 10;
        this.seprectextraverticalpadding = 4;
        this.autoRowWrapModeWidth = 540;
        this.rowWrapMode = true;
        this.rowWrapModeWrapColumn = 2;
        this.formattedValueCache = {};
        this.columnSections = [];
        this.scrollLimitHit = new BehaviorSubject$1(0);
        this.touchscroll = new EventEmitter();
    }
    Object.defineProperty(CanvasTableComponent.prototype, "topindex", {
        get: /**
         * @return {?}
         */
        function () { return this._topindex; },
        set: /**
         * @param {?} topindex
         * @return {?}
         */
        function (topindex) {
            if (this._topindex !== topindex) {
                this._topindex = topindex;
                this.hasChanges = true;
            }
        },
        enumerable: true,
        configurable: true
    });
    
    Object.defineProperty(CanvasTableComponent.prototype, "horizScroll", {
        get: /**
         * @return {?}
         */
        function () { return this._horizScroll; },
        set: /**
         * @param {?} horizScroll
         * @return {?}
         */
        function (horizScroll) {
            if (this._horizScroll !== horizScroll) {
                this._horizScroll = horizScroll;
                this.hasChanges = true;
            }
        },
        enumerable: true,
        configurable: true
    });
    
    Object.defineProperty(CanvasTableComponent.prototype, "columns", {
        get: /**
         * @return {?}
         */
        function () { return this._columns; },
        set: /**
         * @param {?} columns
         * @return {?}
         */
        function (columns) {
            if (this._columns !== columns) {
                this._columns = columns;
                this.recalculateColumnSections();
                this.calculateColumnFooterSums();
                this.hasChanges = true;
            }
        },
        enumerable: true,
        configurable: true
    });
    
    Object.defineProperty(CanvasTableComponent.prototype, "hoverRowIndex", {
        get: /**
         * @return {?}
         */
        function () { return this._hoverRowIndex; },
        set: /**
         * @param {?} hoverRowIndex
         * @return {?}
         */
        function (hoverRowIndex) {
            if (this._hoverRowIndex !== hoverRowIndex) {
                this._hoverRowIndex = hoverRowIndex;
                this.hasChanges = true;
            }
        },
        enumerable: true,
        configurable: true
    });
    
    
    /**
     * @return {?}
     */
    CanvasTableComponent.prototype.ngDoCheck = /**
     * @return {?}
     */
    function () {
        if (this.canv) {
            var /** @type {?} */ devicePixelRatio_1 = window.devicePixelRatio ? window.devicePixelRatio : 1;
            var /** @type {?} */ wantedWidth = Math.floor(this.canv.scrollWidth * devicePixelRatio_1);
            var /** @type {?} */ wantedHeight = Math.floor(this.canv.scrollHeight * devicePixelRatio_1);
            if (this.canv.width !== wantedWidth || this.canv.height !== wantedHeight) {
                this.canv.width = wantedWidth;
                this.canv.height = wantedHeight;
                if (devicePixelRatio_1 !== 1) {
                    this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
                }
                this.maxVisibleRows = this.canv.scrollHeight / this.rowheight;
                this.hasChanges = true;
                if (this.canv.scrollWidth < this.autoRowWrapModeWidth) {
                    this.rowWrapMode = true;
                }
                else {
                    this.rowWrapMode = false;
                }
            }
        }
    };
    /**
     * @return {?}
     */
    CanvasTableComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.canv = this.canvRef.nativeElement;
        this.ctx = this.canv.getContext("2d");
        this.canv.addEventListener("DOMMouseScroll", function (event) {
            event.preventDefault();
            _this.topindex -= -1 * event.detail / 1;
            _this.enforceScrollLimit();
        });
        this.canv.onmousewheel = function (event) {
            event.preventDefault();
            _this.topindex -= event.wheelDelta / 100;
            _this.enforceScrollLimit();
        };
        var /** @type {?} */ checkIfScrollbarArea = function (clientX, clientY, wholeScrollbar) {
            if (!_this.scrollBarRect) {
                return false;
            }
            var /** @type {?} */ canvrect = _this.canv.getBoundingClientRect();
            var /** @type {?} */ x = clientX - canvrect.left;
            var /** @type {?} */ y = clientY - canvrect.top;
            return x > _this.scrollBarRect.x && x < _this.scrollBarRect.x + _this.scrollBarRect.width &&
                (wholeScrollbar || y > _this.scrollBarRect.y && y < _this.scrollBarRect.y + _this.scrollBarRect.height);
        };
        var /** @type {?} */ checkScrollbarDrag = function (clientX, clientY) {
            if (!_this.scrollBarRect) {
                return;
            }
            var /** @type {?} */ canvrect = _this.canv.getBoundingClientRect();
            _this.touchdownxy = { x: clientX - canvrect.left, y: clientY - canvrect.top };
            if (checkIfScrollbarArea(clientX, clientY)) {
                _this.scrollbardrag = true;
            }
        };
        this.canv.onmousedown = function (event) {
            event.preventDefault();
            checkScrollbarDrag(event.clientX, event.clientY);
            _this.lastMouseDownEvent = event;
        };
        var /** @type {?} */ previousTouchY;
        var /** @type {?} */ previousTouchX;
        var /** @type {?} */ touchMoved = false;
        this.canv.addEventListener('touchstart', function (event) {
            _this.canv.focus(); // Take away focus from search field
            previousTouchX = event.targetTouches[0].clientX;
            previousTouchY = event.targetTouches[0].clientY;
            if (checkScrollbarDrag(event.targetTouches[0].clientX, event.targetTouches[0].clientY)) {
                event.preventDefault();
            }
            touchMoved = false;
        });
        this.canv.addEventListener('touchmove', function (event) {
            event.preventDefault();
            touchMoved = true;
            if (event.targetTouches.length === 1) {
                var /** @type {?} */ newTouchY = event.targetTouches[0].clientY;
                var /** @type {?} */ newTouchX = event.targetTouches[0].clientX;
                if (_this.scrollbardrag === true) {
                    _this.doScrollBarDrag(newTouchY);
                }
                else {
                    _this.topindex -= (newTouchY - previousTouchY) / _this.rowheight;
                    if (!_this.rowWrapMode) {
                        _this.horizScroll -= (newTouchX - previousTouchX);
                    }
                    previousTouchY = newTouchY;
                    previousTouchX = newTouchX;
                }
                _this.enforceScrollLimit();
                _this.touchscroll.emit(_this.horizScroll);
            }
        }, false);
        this.canv.addEventListener('touchend', function (event) {
            event.preventDefault();
            if (!touchMoved) {
                _this.selectRow(event.changedTouches[0].clientX, event.changedTouches[0].clientY);
            }
            if (_this.scrollbardrag) {
                _this.scrollbardrag = false;
            }
        });
        this.renderer.listenGlobal('window', 'mousemove', function (event) {
            if (_this.scrollbardrag === true) {
                event.preventDefault();
                _this.doScrollBarDrag(event.clientY);
            }
        });
        this.canv.onmousemove = function (event) {
            if (_this.scrollbardrag === true) {
                event.preventDefault();
                return;
            }
            var /** @type {?} */ canvrect = _this.canv.getBoundingClientRect();
            var /** @type {?} */ newHoverRowIndex = Math.floor(_this.topindex + (event.clientY - canvrect.top) / _this.rowheight);
            if (_this.scrollbardrag || checkIfScrollbarArea(event.clientX, event.clientY, true)) {
                newHoverRowIndex = null;
            }
            if (_this.hoverRowIndex !== newHoverRowIndex) {
                _this.hoverRowIndex = newHoverRowIndex;
                if (_this.lastMouseDownEvent) {
                    _this.selectRow(_this.lastMouseDownEvent.clientX, event.clientY);
                }
            }
            if (_this.hoverRowIndex !== null) {
                var /** @type {?} */ clientX = event.clientX - canvrect.left;
                var /** @type {?} */ colIndex_1 = _this.getColIndexByClientX(clientX);
                var /** @type {?} */ colStartX = _this.columns.reduce(function (prev, curr, ndx) { return ndx < colIndex_1 ? prev + curr.width : prev; }, 0);
                if (!event.shiftKey && !_this.lastMouseDownEvent && _this.columns[colIndex_1] && _this.columns[colIndex_1].tooltipText) {
                    _this.floatingTooltip = new FloatingTooltip((_this.hoverRowIndex - _this.topindex) * _this.rowheight, colStartX - _this.horizScroll, _this.columns[colIndex_1].width, _this.rowheight, _this.columns[colIndex_1].tooltipText);
                    setTimeout(function () {
                        if (_this.columnOverlay) {
                            _this.columnOverlay.show(1000);
                        }
                    }, 0);
                }
                else {
                    _this.floatingTooltip = null;
                }
            }
            else {
                _this.floatingTooltip = null;
            }
        };
        this.canv.onmouseout = function (event) {
            var /** @type {?} */ newHoverRowIndex = null;
            if (_this.hoverRowIndex !== newHoverRowIndex) {
                _this.hoverRowIndex = newHoverRowIndex;
            }
        };
        this.renderer.listenGlobal('window', 'mouseup', function (event) {
            _this.touchdownxy = undefined;
            _this.lastMouseDownEvent = undefined;
            if (_this.scrollbardrag) {
                _this.scrollbardrag = false;
            }
        });
        this.canv.onmouseup = function (event) {
            event.preventDefault();
            if (!_this.scrollbardrag &&
                _this.lastMouseDownEvent &&
                event.clientX === _this.lastMouseDownEvent.clientX &&
                event.clientY === _this.lastMouseDownEvent.clientY) {
                _this.selectRow(event.clientX, event.clientY);
            }
            _this.lastMouseDownEvent = null;
        };
        this.renderer.listenGlobal('window', 'resize', function () { return true; });
        var /** @type {?} */ paintLoop = function () {
            if (_this.hasChanges) {
                try {
                    _this.dopaint();
                }
                catch (/** @type {?} */ e) {
                    console.log(e);
                }
                _this.hasChanges = false;
            }
            window.requestAnimationFrame(function () { return paintLoop(); });
        };
        this._ngZone.runOutsideAngular(function () {
            return window.requestAnimationFrame(function () { return paintLoop(); });
        });
    };
    /**
     * @param {?} event
     * @return {?}
     */
    CanvasTableComponent.prototype.dragColumnOverlay = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        var /** @type {?} */ canvrect = this.canv.getBoundingClientRect();
        var /** @type {?} */ selectedColIndex = this.getColIndexByClientX(event.clientX - canvrect.left);
        var /** @type {?} */ selectedRowIndex = Math.floor(this.topindex + (event.clientY - canvrect.top) / this.rowheight);
        if (!this.columns[selectedColIndex].checkbox) {
            console.log("Dragstart", event);
            event.dataTransfer.setData("text/plain", "rowIndex:" + selectedRowIndex);
        }
        else {
            event.preventDefault();
            this.lastMouseDownEvent = event;
        }
        this.selectListener.rowSelected(selectedRowIndex, -1, this.rows[selectedRowIndex]);
        this.hasChanges = true;
    };
    /**
     * @param {?} event
     * @return {?}
     */
    CanvasTableComponent.prototype.columnOverlayClicked = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.lastMouseDownEvent = null;
        this.selectRow(event.clientX, event.clientY);
    };
    /**
     * @param {?} clientY
     * @return {?}
     */
    CanvasTableComponent.prototype.doScrollBarDrag = /**
     * @param {?} clientY
     * @return {?}
     */
    function (clientY) {
        var /** @type {?} */ canvrect = this.canv.getBoundingClientRect();
        this.topindex = this.rows.length * ((clientY - canvrect.top) / this.canv.scrollHeight);
        this.enforceScrollLimit();
    };
    /**
     * @param {?} clientX
     * @return {?}
     */
    CanvasTableComponent.prototype.getColIndexByClientX = /**
     * @param {?} clientX
     * @return {?}
     */
    function (clientX) {
        var /** @type {?} */ x = -this.horizScroll;
        var /** @type {?} */ selectedColIndex = 0;
        for (; selectedColIndex < this.columns.length; selectedColIndex++) {
            var /** @type {?} */ col = this.columns[selectedColIndex];
            if (clientX >= x && clientX < x + col.width) {
                break;
            }
            x += col.width;
        }
        return selectedColIndex;
    };
    /**
     * @param {?} clientX
     * @param {?} clientY
     * @param {?=} multiSelect
     * @return {?}
     */
    CanvasTableComponent.prototype.selectRow = /**
     * @param {?} clientX
     * @param {?} clientY
     * @param {?=} multiSelect
     * @return {?}
     */
    function (clientX, clientY, multiSelect) {
        var /** @type {?} */ canvrect = this.canv.getBoundingClientRect();
        clientX -= canvrect.left;
        var /** @type {?} */ selectedRowIndex = Math.floor(this.topindex + (clientY - canvrect.top) / this.rowheight);
        this.selectListener.rowSelected(selectedRowIndex, this.getColIndexByClientX(clientX), this.rows[selectedRowIndex], multiSelect);
        this.hasChanges = true;
    };
    /**
     * @param {?} minwidth
     * @param {?} maxwidth
     * @return {?}
     */
    CanvasTableComponent.prototype.autoAdjustColumnWidths = /**
     * @param {?} minwidth
     * @param {?} maxwidth
     * @return {?}
     */
    function (minwidth, maxwidth) {
        var _this = this;
        var /** @type {?} */ padding = this.colpaddingleft + this.colpaddingright;
        var /** @type {?} */ devicePixelRatio = window.devicePixelRatio ? window.devicePixelRatio : 1;
        this.columns.forEach(function (c) {
            var /** @type {?} */ newwidth = devicePixelRatio * Math.round(_this.ctx.measureText(c.name).width + padding);
            if (newwidth > maxwidth) {
                newwidth = maxwidth;
            }
            if (newwidth > minwidth) {
                c.width = newwidth;
            }
        });
        var _loop_1 = function (rowindex) {
            var /** @type {?} */ row = this_1.rows[rowindex];
            this_1.columns.forEach(function (c) {
                var /** @type {?} */ valueWidth = Math.round((_this.ctx.measureText(c.getFormattedValue ?
                    c.getFormattedValue(c.getValue(row)) :
                    c.getValue(row)).width + padding) * devicePixelRatio);
                if (valueWidth > maxwidth) {
                    valueWidth = maxwidth;
                }
                if (valueWidth > c.width) {
                    c.width = valueWidth;
                }
            });
        };
        var this_1 = this;
        for (var /** @type {?} */ rowindex = this.topindex; rowindex <
            this.topindex + this.canv.height / this.rowheight &&
            rowindex < this.rows.length; rowindex++) {
            _loop_1(rowindex);
        }
        this.hasChanges = true;
    };
    /**
     * @return {?}
     */
    CanvasTableComponent.prototype.scrollTop = /**
     * @return {?}
     */
    function () {
        this.topindex = 0;
        this.hasChanges = true;
    };
    Object.defineProperty(CanvasTableComponent.prototype, "rows", {
        get: /**
         * @return {?}
         */
        function () {
            return this._rows;
        },
        set: /**
         * @param {?} rows
         * @return {?}
         */
        function (rows) {
            if (this._rows !== rows) {
                this._rows = rows;
                this.calculateColumnFooterSums();
                this.hasChanges = true;
            }
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    CanvasTableComponent.prototype.calculateColumnFooterSums = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.columns.forEach(function (col) {
            if (col.footerSumReduce) {
                col.footerText = col.getFormattedValue(_this.rows.reduce(function (prev, row) { return col.footerSumReduce(prev, col.getValue(row)); }, 0));
            }
        });
    };
    /**
     * @return {?}
     */
    CanvasTableComponent.prototype.recalculateColumnSections = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ leftX = 0;
        this.columnSections = this.columns.reduce(function (accumulated, current) {
            var /** @type {?} */ ret;
            if (accumulated.length === 0 ||
                accumulated[accumulated.length - 1].columnSectionName !== current.columnSectionName) {
                ret = accumulated.concat([
                    new CanvasTableColumnSection(current.columnSectionName, current.width, leftX, current.backgroundColor)
                ]);
            }
            else if (accumulated.length > 0 && accumulated[accumulated.length - 1].columnSectionName === current.columnSectionName) {
                accumulated[accumulated.length - 1].width += current.width;
                ret = accumulated;
            }
            leftX += current.width;
            return ret;
        }, []);
        this.hasChanges = true;
    };
    /**
     * @return {?}
     */
    CanvasTableComponent.prototype.enforceScrollLimit = /**
     * @return {?}
     */
    function () {
        if (this.topindex < 0) {
            this.topindex = 0;
        }
        else if (this.rows.length < this.maxVisibleRows) {
            this.topindex = 0;
        }
        else if (this.topindex + this.maxVisibleRows > this.rows.length) {
            this.topindex = this.rows.length - this.maxVisibleRows;
            // send max rows hit events (use to fetch more data)
            this.scrollLimitHit.next(this.rows.length);
        }
        var /** @type {?} */ columnsTotalWidth = this.columns.reduce(function (width, col) {
            return col.width + width;
        }, 0);
        if (this.horizScroll < 0) {
            this.horizScroll = 0;
        }
        else if (this.canv.scrollWidth < columnsTotalWidth &&
            this.horizScroll + this.canv.scrollWidth > columnsTotalWidth) {
            this.horizScroll = columnsTotalWidth - this.canv.scrollWidth;
        }
    };
    /**
     * Draws a rounded rectangle using the current state of the canvas.
     * If you omit the last three params, it will draw a rectangle
     * outline with a 5 pixel border radius
     * @param {?} ctx
     * @param {?} x The top left x coordinate
     * @param {?} y The top left y coordinate
     * @param {?} width The width of the rectangle
     * @param {?} height The height of the rectangle
     * @param {?=} radius
     * @param {?=} fill
     * @param {?=} stroke
     * @return {?}
     */
    CanvasTableComponent.prototype.roundRect = /**
     * Draws a rounded rectangle using the current state of the canvas.
     * If you omit the last three params, it will draw a rectangle
     * outline with a 5 pixel border radius
     * @param {?} ctx
     * @param {?} x The top left x coordinate
     * @param {?} y The top left y coordinate
     * @param {?} width The width of the rectangle
     * @param {?} height The height of the rectangle
     * @param {?=} radius
     * @param {?=} fill
     * @param {?=} stroke
     * @return {?}
     */
    function (ctx, x, y, width, height, radius, fill, stroke) {
        if (typeof stroke == 'undefined') {
            stroke = true;
        }
        if (typeof radius === 'undefined') {
            radius = 5;
        }
        if (typeof radius === 'number') {
            radius = { tl: radius, tr: radius, br: radius, bl: radius };
        }
        else {
            var /** @type {?} */ defaultRadius = { tl: 0, tr: 0, br: 0, bl: 0 };
            for (var /** @type {?} */ side in defaultRadius) {
                radius[side] = radius[side] || defaultRadius[side];
            }
        }
        ctx.beginPath();
        ctx.moveTo(x + radius.tl, y);
        ctx.lineTo(x + width - radius.tr, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius.tr);
        ctx.lineTo(x + width, y + height - radius.br);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius.br, y + height);
        ctx.lineTo(x + radius.bl, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius.bl);
        ctx.lineTo(x, y + radius.tl);
        ctx.quadraticCurveTo(x, y, x + radius.tl, y);
        ctx.closePath();
        if (fill) {
            ctx.fill();
        }
        if (stroke) {
            ctx.stroke();
        }
    };
    Object.defineProperty(CanvasTableComponent.prototype, "rowheight", {
        get: /**
         * @return {?}
         */
        function () {
            return this.rowWrapMode ? this._rowheight * 2 : this._rowheight;
        },
        set: /**
         * @param {?} rowheight
         * @return {?}
         */
        function (rowheight) {
            if (this._rowheight !== rowheight) {
                this._rowheight = rowheight;
                this.hasChanges = true;
            }
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    CanvasTableComponent.prototype.dopaint = /**
     * @return {?}
     */
    function () {
        this.ctx.textBaseline = "middle";
        this.ctx.font = this.fontheight + "px " + this.fontFamily;
        var /** @type {?} */ canvwidth = this.canv.scrollWidth;
        var /** @type {?} */ canvheight = this.canv.scrollHeight;
        var /** @type {?} */ colx = 0 - this.horizScroll;
        // Columns
        for (var /** @type {?} */ colindex = 0; colindex < this.columns.length; colindex++) {
            var /** @type {?} */ col = this.columns[colindex];
            if (colx + col.width > 0 && colx < canvwidth) {
                this.ctx.fillStyle = col.backgroundColor ? col.backgroundColor : "#fff";
                this.ctx.fillRect(colx, 0, colindex === this.columns.length - 1 ?
                    canvwidth - colx :
                    col.width, canvheight);
            }
            colx += col.width;
        }
        if (this.rows.length < 1) {
            return;
        }
        // Rows
        for (var /** @type {?} */ n = this.topindex; n < this.rows.length; n += 1.0) {
            var /** @type {?} */ rowIndex = Math.floor(n);
            if (rowIndex > this.rows.length) {
                break;
            }
            var /** @type {?} */ rowobj = this.rows[rowIndex];
            var /** @type {?} */ halfrowheight = (this.rowheight / 2);
            var /** @type {?} */ rowy = (rowIndex - this.topindex) * this.rowheight;
            if (rowobj) {
                // Clear row area
                // Alternating row colors:
                // let rowBgColor : string = (rowIndex%2===0 ? "#e8e8e8" : "rgba(255,255,255,0.7)");
                // Single row color:
                var /** @type {?} */ rowBgColor = "#fff";
                var /** @type {?} */ isBoldRow = this.selectListener.isBoldRow(rowobj);
                var /** @type {?} */ isSelectedRow = this.selectListener.isSelectedRow(rowobj);
                if (this.hoverRowIndex === rowIndex) {
                    rowBgColor = this.hoverRowColor;
                }
                if (isSelectedRow) {
                    rowBgColor = this.selectedRowColor;
                }
                this.ctx.fillStyle = rowBgColor;
                this.ctx.fillRect(0, rowy, canvwidth, this.rowheight);
                var /** @type {?} */ x = 0;
                for (var /** @type {?} */ colindex = 0; colindex < this.columns.length; colindex++) {
                    var /** @type {?} */ col = this.columns[colindex];
                    var /** @type {?} */ val = col.getValue(rowobj);
                    var /** @type {?} */ formattedVal = void 0;
                    var /** @type {?} */ formattedValueCacheKey = colindex + ":" + val;
                    if (this.formattedValueCache[formattedValueCacheKey]) {
                        formattedVal = this.formattedValueCache[formattedValueCacheKey];
                    }
                    else if (("" + val).length > 0 && col.getFormattedValue) {
                        formattedVal = col.getFormattedValue(val);
                        this.formattedValueCache[formattedValueCacheKey] = formattedVal;
                    }
                    else {
                        formattedVal = "" + val;
                    }
                    if (this.rowWrapMode && col.rowWrapModeHidden) {
                        continue;
                    }
                    else if (this.rowWrapMode && col.rowWrapModeChipCounter && parseInt(val) > 1) {
                        this.ctx.save();
                        this.ctx.strokeStyle = "#01579B";
                        if (isSelectedRow) {
                            this.ctx.fillStyle = "#000";
                        }
                        else {
                            this.ctx.fillStyle = "#01579B";
                        }
                        this.roundRect(this.ctx, canvwidth - 50, rowy + 3, 28, 15, 10, true);
                        this.ctx.font = "10px " + this.fontFamily;
                        this.ctx.strokeStyle = "#000";
                        if (isSelectedRow) {
                            this.ctx.fillStyle = "#01579B";
                        }
                        else {
                            this.ctx.fillStyle = "#000";
                        }
                        this.ctx.textAlign = "center";
                        this.ctx.fillText(formattedVal + "", canvwidth - 36, rowy + halfrowheight - 15);
                        this.ctx.restore();
                        continue;
                    }
                    else if (this.rowWrapMode && col.rowWrapModeChipCounter) {
                        continue;
                    }
                    if (this.rowWrapMode && colindex === this.rowWrapModeWrapColumn) {
                        x = 0;
                    }
                    x += this.colpaddingleft;
                    if ((x - this.horizScroll + col.width) >= 0 && formattedVal.length > 0) {
                        this.ctx.fillStyle = "#000";
                        if (isSelectedRow) {
                            this.ctx.fillStyle = "#01579B";
                        }
                        if (this.rowWrapMode) {
                            // Wrap rows if in row wrap mode
                            if (colindex >= this.rowWrapModeWrapColumn) {
                                this.ctx.save();
                                this.ctx.font = "14px " + this.fontFamily;
                                this.ctx.fillStyle = "#01579B";
                                this.ctx.fillText(formattedVal, x, rowy + halfrowheight + 12);
                                this.ctx.restore();
                            }
                            else if (col.rowWrapModeMuted) {
                                this.ctx.save();
                                this.ctx.font = "12px " + this.fontFamily;
                                this.ctx.fillStyle = "#777";
                                this.ctx.fillText(formattedVal, x, rowy + halfrowheight - 15);
                                this.ctx.restore();
                            }
                            else {
                                if (isBoldRow) {
                                    this.ctx.save();
                                    this.ctx.font = "bold " + this.ctx.font;
                                }
                                this.ctx.fillText(formattedVal, x, rowy + halfrowheight - 15);
                                if (isBoldRow) {
                                    this.ctx.restore();
                                }
                            }
                        }
                        else if (x - this.horizScroll < canvwidth) {
                            var /** @type {?} */ texty = rowy + halfrowheight;
                            var /** @type {?} */ textx = x - this.horizScroll;
                            var /** @type {?} */ width = col.width - this.colpaddingright - this.colpaddingleft;
                            this.ctx.save();
                            this.ctx.beginPath();
                            this.ctx.moveTo(textx, rowy);
                            this.ctx.lineTo(textx + width, rowy);
                            this.ctx.lineTo(textx + width, rowy + this.rowheight);
                            this.ctx.lineTo(textx, rowy + this.rowheight);
                            this.ctx.closePath();
                            this.ctx.clip();
                            if (col.checkbox) {
                                this.ctx.beginPath();
                                this.ctx.arc(textx + width / 2, texty, 6, 0, 2 * Math.PI);
                                this.ctx.stroke();
                                if (val) {
                                    this.ctx.beginPath();
                                    this.ctx.arc(textx + width / 2, texty, 4, 0, 2 * Math.PI);
                                    this.ctx.fill();
                                }
                            }
                            else {
                                if (col.textAlign === 1) {
                                    textx += width;
                                    this.ctx.textAlign = "end";
                                }
                                if (isBoldRow) {
                                    this.ctx.font = "bold " + this.ctx.font;
                                }
                                this.ctx.fillText(formattedVal, textx, texty);
                            }
                            this.ctx.restore();
                        }
                    }
                    x += (Math.round(col.width * (this.rowWrapMode && col.rowWrapModeMuted ? (10 / this.fontheight) : 1)) - this.colpaddingleft); // We've already added colpaddingleft above
                }
            }
            else {
                break;
            }
            if (rowy > canvheight) {
                break;
            }
            this.ctx.fillStyle = "#000";
        }
        // Column separators
        if (!this.rowWrapMode) {
            // No column separators in row wrap mode
            this.ctx.strokeStyle = "#bbb";
            var /** @type {?} */ x = 0;
            for (var /** @type {?} */ colindex = 0; colindex < this.columns.length; colindex++) {
                this.ctx.beginPath();
                this.ctx.moveTo(x - this.horizScroll, 0);
                this.ctx.lineTo(x - this.horizScroll, canvheight);
                this.ctx.stroke();
                x += this.columns[colindex].width;
            }
        }
        // Scrollbar
        var /** @type {?} */ scrollbarheight = canvheight / this.rows.length * this.rowheight;
        if (scrollbarheight < 20) {
            scrollbarheight = 20;
        }
        var /** @type {?} */ scrollbarpos = (this.topindex / (this.rows.length - this.maxVisibleRows)) * (canvheight - scrollbarheight);
        if (scrollbarheight < canvheight) {
            var /** @type {?} */ scrollbarverticalpadding = 4;
            var /** @type {?} */ scrollbarwidth = 20;
            var /** @type {?} */ scrollbarx = canvwidth - scrollbarwidth;
            this.ctx.fillStyle = "#aaa";
            this.ctx.fillRect(scrollbarx, 0, scrollbarwidth, canvheight);
            this.ctx.fillStyle = "#fff";
            this.scrollBarRect = { x: scrollbarx + 1,
                y: scrollbarpos + scrollbarverticalpadding / 2,
                width: scrollbarwidth - 2,
                height: scrollbarheight - scrollbarverticalpadding };
            if (this.scrollbardrag) {
                this.ctx.fillStyle = "rgba(200,200,255,0.5)";
                this.roundRect(this.ctx, this.scrollBarRect.x - 4, this.scrollBarRect.y - 4, this.scrollBarRect.width + 8, this.scrollBarRect.height + 8, 5, true);
                this.ctx.fillStyle = "#fff";
                this.ctx.fillRect(this.scrollBarRect.x, this.scrollBarRect.y, this.scrollBarRect.width, this.scrollBarRect.height);
            }
            else {
                this.ctx.fillStyle = "#fff";
                this.ctx.fillRect(this.scrollBarRect.x, this.scrollBarRect.y, this.scrollBarRect.width, this.scrollBarRect.height);
            }
        }
    };
    CanvasTableComponent.incrementalId = 1;
    CanvasTableComponent.decorators = [
        { type: Component, args: [{
                    selector: 'canvastable',
                    template: "    \n      <canvas #thecanvas style=\"position: absolute; width: 100%; height: 100%; user-select: none;\" \n          tabindex=\"0\"></canvas>\n          <div #columnOverlay draggable=\"true\" [matTooltip]=\"floatingTooltip.tooltipText\" style=\"position: absolute;\"\n                (DOMMouseScroll)=\"floatingTooltip=null\"\n                (mousewheel)=\"floatingTooltip=null\"\n                (mousemove)=\"canv.onmousemove($event)\"               \n                (click)=\"columnOverlayClicked($event)\"\n                [style.top.px]=\"floatingTooltip.top\" \n                [style.left.px]=\"floatingTooltip.left\"\n                [style.width.px]=\"floatingTooltip.width\"\n                [style.height.px]=\"floatingTooltip.height\"\n                  *ngIf=\"floatingTooltip\" \n                (dragstart)=\"dragColumnOverlay($event)\"\n                >              \n      </div>\n      "
                },] },
    ];
    /** @nocollapse */
    CanvasTableComponent.ctorParameters = function () { return [
        { type: ElementRef, },
        { type: Renderer, },
        { type: NgZone, },
    ]; };
    CanvasTableComponent.propDecorators = {
        "canvRef": [{ type: ViewChild, args: ["thecanvas",] },],
        "columnOverlay": [{ type: ViewChild, args: [MatTooltip,] },],
        "selectListener": [{ type: Input },],
        "touchscroll": [{ type: Output },],
    };
    return CanvasTableComponent;
}());
var CanvasTableContainerComponent = (function () {
    function CanvasTableContainerComponent(renderer) {
        this.renderer = renderer;
        this.sortColumn = 0;
        this.sortDescending = false;
        this.savedColumnWidths = [];
        this.configname = "default";
        this.sortToggled = new EventEmitter();
    }
    /**
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        var /** @type {?} */ savedColumnWidthsString = localStorage.getItem(this.configname + "CanvasTableColumnWidths");
        if (savedColumnWidthsString) {
            this.savedColumnWidths = JSON.parse(savedColumnWidthsString);
        }
        this.renderer.listenGlobal('window', 'mousemove', function (event) {
            if (_this.colResizePreviousX) {
                event.preventDefault();
                event.stopPropagation();
                _this.colresize(event.clientX);
            }
        });
        this.renderer.listenGlobal('window', 'mouseup', function (event) {
            if (_this.colResizePreviousX) {
                event.preventDefault();
                event.stopPropagation();
                _this.colresizeend();
            }
        });
    };
    /**
     * @param {?} clientX
     * @param {?} colIndex
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.colresizestart = /**
     * @param {?} clientX
     * @param {?} colIndex
     * @return {?}
     */
    function (clientX, colIndex) {
        if (colIndex > 0) {
            this.colResizePreviousX = clientX;
            this.colResizeColumnIndex = colIndex;
        }
    };
    /**
     * @param {?} clientX
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.colresize = /**
     * @param {?} clientX
     * @return {?}
     */
    function (clientX) {
        var _this = this;
        if (this.colResizePreviousX) {
            new AnimationFrameThrottler("colresize", function () {
                var /** @type {?} */ prevcol = _this.canvastable.columns[_this.colResizeColumnIndex - 1];
                if (prevcol && prevcol.width) {
                    prevcol.width += (clientX - _this.colResizePreviousX);
                    if (prevcol.width < 20) {
                        prevcol.width = 20;
                    }
                    _this.canvastable.hasChanges = true;
                    _this.columnResized = true;
                    _this.colResizePreviousX = clientX;
                    _this.saveColumnWidths();
                }
            });
        }
    };
    /**
     * @param {?} colIndex
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.sumWidthsBefore = /**
     * @param {?} colIndex
     * @return {?}
     */
    function (colIndex) {
        var /** @type {?} */ ret = 0;
        for (var /** @type {?} */ n = 0; n < colIndex; n++) {
            ret += this.canvastable.columns[n].width;
        }
        return ret;
    };
    /**
     * @param {?} colIndex
     * @param {?} defaultWidth
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.getSavedColumnWidth = /**
     * @param {?} colIndex
     * @param {?} defaultWidth
     * @return {?}
     */
    function (colIndex, defaultWidth) {
        return this.savedColumnWidths[colIndex] ?
            this.savedColumnWidths[colIndex] :
            defaultWidth;
    };
    /**
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.saveColumnWidths = /**
     * @return {?}
     */
    function () {
        this.savedColumnWidths = this.canvastable.columns.map(function (col) { return col.width; });
        localStorage.setItem(this.configname + "CanvasTableColumnWidths", JSON.stringify(this.savedColumnWidths));
    };
    /**
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.colresizeend = /**
     * @return {?}
     */
    function () {
        this.colResizePreviousX = null;
        this.colResizeColumnIndex = null;
    };
    /**
     * @param {?} evt
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.horizScroll = /**
     * @param {?} evt
     * @return {?}
     */
    function (evt) {
        this.canvastable.horizScroll = evt.target.scrollLeft;
    };
    /**
     * @param {?} column
     * @return {?}
     */
    CanvasTableContainerComponent.prototype.toggleSort = /**
     * @param {?} column
     * @return {?}
     */
    function (column) {
        if (column === null) {
            return;
        }
        if (this.columnResized) {
            this.columnResized = false;
            return;
        }
        if (column === this.sortColumn) {
            this.sortDescending = !this.sortDescending;
        }
        else {
            this.sortColumn = column;
        }
        this.sortToggled.emit({ sortColumn: this.sortColumn, sortDescending: this.sortDescending });
    };
    CanvasTableContainerComponent.decorators = [
        { type: Component, args: [{
                    moduleId: window['_moduleidroot'] + '/canvastable/',
                    selector: "canvastablecontainer",
                    template: "<style> .footerColumn { position: absolute; bottom: 0px; user-select: none; -webkit-user-select: none; color: #01579B;                         white-space: nowrap; height: 25px; padding-top: 5px;             text-align: right; font-weight: bold;    } </style> <div #tablecontainer style=\" position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;                     overflow-x: auto; overflow-y: hidden;  user-select: none;  -webkit-user-select: none;\" (scroll)=\"horizScroll($event)\" >         <div [hidden]=\"canvastable.rowWrapMode\" *ngFor=\"let col of canvastable.columns; let colIndex = index\"           (touchstart)=\"colresizestart($event.targetTouches[0].clientX,colIndex)\" (mousedown)=\"colresizestart($event.clientX,colIndex)\"             (touchmove)=\"$event.preventDefault();colresize($event.targetTouches[0].clientX)\" (touchend)=\"colresizeend()\"             (click)=\"toggleSort(col.sortColumn)\" style=\" position: absolute; top: 0px; user-select: none; -webkit-user-select: none; color: #01579B;           padding-left: 5px; white-space: nowrap; height: 25px; padding-top: 5px; text-align: center; \" [style.width]=\"col.width+'px'\" [style.backgroundColor]=\"col.backgroundColor ? col.backgroundColor : inherit\" [style.left]=\"sumWidthsBefore(colIndex)+'px'\" [style.cursor]=\"col.sortColumn!==null ? 'pointer' : 'default'\" > <mat-icon *ngIf=\"sortColumn===col.sortColumn\" style=\"font-size: 12px;\"> {{sortDescending ? 'arrow_upward' : 'arrow_downward'}} </mat-icon> {{col.name}}           </div> <div [style.display]=\"canvastable.rowWrapMode ? 'flex':'none'\">         <div *ngFor=\"let col of canvastable.columns; let colIndex = index\"          (click)=\"toggleSort(col.sortColumn)\" (touchstart)=\"$event.preventDefault();toggleSort(col.sortColumn)\" style=\"    padding: 4px;                           margin-right: 5px; border-radius: 5px; user-select: none; -webkit-user-select: none; \" [style.backgroundColor]=\"sortColumn!==col.sortColumn ? 'inherit' : '#01579B'\" [style.color]=\"sortColumn===col.sortColumn ? '#fff' : '#01579B'\" [style.cursor]=\"col.sortColumn!==null ? 'pointer' : 'default'\" > <mat-icon *ngIf=\"sortColumn===col.sortColumn\" style=\"font-size: 12px;\">{{sortDescending ? 'arrow_upward' : 'arrow_downward'}}</mat-icon>{{col.name}}           </div>         </div> <div #tablebodycontainer style=\"position: absolute;  top: 25px;  bottom: 25px;  width: 100%;\"  [style.left]=\"canvastable.horizScroll+'px'\">           <canvastable [selectListener]=\"canvastableselectlistener\" (touchscroll)=\"tablecontainer.scrollLeft=$event;tablebodycontainer.style.left=$event+'px'\"> </canvastable> </div> <div [hidden]=\"canvastable.rowWrapMode\" *ngFor=\"let col of canvastable.columns; let colIndex = index\"           (touchstart)=\"colresizestart($event.targetTouches[0].clientX,colIndex)\" (mousedown)=\"colresizestart($event.clientX,colIndex)\"             (touchmove)=\"$event.preventDefault();colresize($event.targetTouches[0].clientX)\" (touchend)=\"colresizeend()\"             (click)=\"toggleSort(col.sortColumn)\" class=\"footerColumn\" [style.width]=\"col.width+'px'\" [style.backgroundColor]=\"col.backgroundColor ? col.backgroundColor : inherit\" [style.left]=\"(sumWidthsBefore(colIndex))+'px'\" >             <span style=\"padding-right: 10px\">{{col.footerText}}</span> </div> </div>    "
                },] },
    ];
    /** @nocollapse */
    CanvasTableContainerComponent.ctorParameters = function () { return [
        { type: Renderer, },
    ]; };
    CanvasTableContainerComponent.propDecorators = {
        "canvastable": [{ type: ViewChild, args: [CanvasTableComponent,] },],
        "configname": [{ type: Input },],
        "canvastableselectlistener": [{ type: Input },],
        "sortToggled": [{ type: Output },],
    };
    return CanvasTableContainerComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/*
 *  Copyright 2010-2016 FinTech Neo AS ( fintechneo.com )- All rights reserved
 */
var CanvasTableModule = (function () {
    function CanvasTableModule() {
    }
    CanvasTableModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        MatTooltipModule,
                        MatIconModule
                    ],
                    declarations: [CanvasTableComponent, CanvasTableContainerComponent],
                    exports: [CanvasTableComponent, CanvasTableContainerComponent]
                },] },
    ];
    /** @nocollapse */
    CanvasTableModule.ctorParameters = function () { return []; };
    return CanvasTableModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @author Peter Salomonsen ( https://github.com/petersalomonsen )
 */
/**
 * Change notifications are sent with this class containing a string array for the
 * object path and the changed value.
 */
var FormUpdateEvent = (function () {
    function FormUpdateEvent(path, value) {
        this.path = path;
        this.value = value;
    }
    /**
     * @param {?} targetObject
     * @return {?}
     */
    FormUpdateEvent.prototype.applyToObject = /**
     * @param {?} targetObject
     * @return {?}
     */
    function (targetObject) {
        var /** @type {?} */ currentProperty = targetObject;
        for (var /** @type {?} */ pathIndex = 0; pathIndex < this.path.length - 1; pathIndex++) {
            if (!currentProperty[this.path[pathIndex]]) {
                currentProperty[this.path[pathIndex]] = {};
            }
            currentProperty = currentProperty[this.path[pathIndex]];
        }
        currentProperty[this.path[this.path.length - 1]] = this.value;
    };
    return FormUpdateEvent;
}());
/**
 * Helper service for receiving realtime change notifications on individual form controls
 *
 * This service is of no use outside the component lifecycle so it can be provided directly
 * on the component (add to providers array of the \@Component decorator)
 *
 * Start by setting the formGroup property to the formGroup of your component. Then call
 * controlSubscribe() to add value change listeners to all the form controls.
 *
 * A dataservice should subscribe to formUpdatesSubject to listen for changes made by the user,
 * and use patchFormUpdateEvent to patch the form with changes coming from the backend.
 *
 *
 */
var ReactiveFormAssistant = (function () {
    function ReactiveFormAssistant(formBuilder) {
        this.formBuilder = formBuilder;
        this.formArrayPaths = [];
        /**
         * A dataservice should subscribe to this subject to get changes made by the front-end user
         * and pass on these to the backend server.
         */
        this.formUpdatesSubject = new Subject$1();
    }
    /**
     * @param {?} rowctrl
     * @return {?}
     */
    ReactiveFormAssistant.prototype.cloneRow = /**
     * @param {?} rowctrl
     * @return {?}
     */
    function (rowctrl) {
        var _this = this;
        if (rowctrl instanceof FormGroup) {
            var /** @type {?} */ clonedRow_1 = {};
            var /** @type {?} */ fg_1 = (/** @type {?} */ (rowctrl));
            Object.keys(fg_1.controls).forEach(function (k) {
                return clonedRow_1[k] = _this.cloneRow(fg_1.controls[k]);
            });
            return this.formBuilder.group(clonedRow_1);
        }
        else if (rowctrl instanceof FormControl) {
            return new FormControl(null, rowctrl.validator);
        }
    };
    /**
     * @param {?} path
     * @return {?}
     */
    ReactiveFormAssistant.prototype.findControlByPath = /**
     * @param {?} path
     * @return {?}
     */
    function (path) {
        return /** @type {?} */ (path.reduce(function (formGroup, pathpart) {
            return formGroup.controls[pathpart];
        }, this.formGroup));
    };
    /**
     * @param {?} formArray
     * @param {?} rowindex
     * @param {?=} notify
     * @return {?}
     */
    ReactiveFormAssistant.prototype.removeRowFromFormArray = /**
     * @param {?} formArray
     * @param {?} rowindex
     * @param {?=} notify
     * @return {?}
     */
    function (formArray, rowindex, notify) {
        if (notify === void 0) { notify = false; }
        formArray.removeAt(rowindex);
        if (notify) {
            var /** @type {?} */ path = [];
            var /** @type {?} */ group_1 = formArray;
            while (group_1.parent) {
                path.push(Object.keys(group_1.parent.controls)
                    .find(function (k) { return group_1.parent.controls[k] === group_1; }));
                group_1 = group_1.parent;
            }
            path.reverse();
            // Send entire array when deleting
            this.formUpdatesSubject.next(new FormUpdateEvent(path, formArray.value));
        }
    };
    /**
     * @param {?} formArray
     * @param {?=} rowdata
     * @param {?=} notify
     * @return {?}
     */
    ReactiveFormAssistant.prototype.addRowToFormArray = /**
     * @param {?} formArray
     * @param {?=} rowdata
     * @param {?=} notify
     * @return {?}
     */
    function (formArray, rowdata, notify) {
        var _this = this;
        if (notify === void 0) { notify = false; }
        var /** @type {?} */ formArrayTemplate = this.cloneRow(formArray.parent.controls[Object.keys(formArray.parent.controls)
            .find(function (controlName) {
            return formArray.parent.controls[controlName] === formArray;
        })
            + 'ArrayTemplate']);
        formArray.push(formArrayTemplate);
        var /** @type {?} */ ndx = formArray.length - 1;
        var /** @type {?} */ path = this.formArrayPaths.find(function (p) {
            return _this.findControlByPath(p) === formArray;
        });
        path = path.concat(["" + ndx]);
        this.controlsubscribe(formArray.at(ndx), path);
        if (rowdata) {
            formArray.at(ndx).patchValue(rowdata, { emitEvent: notify });
        }
    };
    /**
     * Send full array update (useful when reordering)
     * @param formArray
     */
    /**
     * Send full array update (useful when reordering)
     * @param {?} formArray
     * @return {?}
     */
    ReactiveFormAssistant.prototype.sendFullArray = /**
     * Send full array update (useful when reordering)
     * @param {?} formArray
     * @return {?}
     */
    function (formArray) {
        var _this = this;
        var /** @type {?} */ path = this.formArrayPaths.find(function (p) {
            return _this.findControlByPath(p) === formArray;
        });
        this.formUpdatesSubject.next(new FormUpdateEvent(path, formArray.value));
    };
    /**
     * A dataservice receiving realtime FormUpdateEvent messages from the backend should call this
     * method to apply changes to the form
     *
     * @param msg
     */
    /**
     * A dataservice receiving realtime FormUpdateEvent messages from the backend should call this
     * method to apply changes to the form
     *
     * @param {?} msg
     * @return {?}
     */
    ReactiveFormAssistant.prototype.patchFormUpdateEvent = /**
     * A dataservice receiving realtime FormUpdateEvent messages from the backend should call this
     * method to apply changes to the form
     *
     * @param {?} msg
     * @return {?}
     */
    function (msg) {
        var _this = this;
        if (msg.path.length > 0) {
            // Patching of individual controls
            var /** @type {?} */ currentPath_1 = [];
            var /** @type {?} */ checkArray_1 = function (arr, property) {
                var /** @type {?} */ arrIndex = parseInt(property, 10);
                while (arrIndex >= arr.length) {
                    // Add extra rows if needed
                    // Add extra rows if needed
                    _this.addRowToFormArray(arr);
                }
                return arr.controls[arrIndex];
            };
            var /** @type {?} */ groupToPatch = msg.path.reduce(function (prev, property) {
                currentPath_1.push(property);
                return prev instanceof FormGroup ? prev.controls[property] :
                    prev instanceof FormArray ?
                        checkArray_1(prev, property) :
                        prev;
            }, /** @type {?} */ (this.formGroup));
            if (groupToPatch instanceof FormArray) {
                /**
                 * We're patching the entire form array so we need
                 * to make sure the number of rows matches the incoming data
                 */
                var /** @type {?} */ arrLength = Object.keys(msg.value).length;
                var /** @type {?} */ formArray = /** @type {?} */ (groupToPatch);
                while (arrLength > formArray.length) {
                    this.addRowToFormArray(formArray);
                }
                while (arrLength < formArray.length) {
                    formArray.removeAt(formArray.length - 1);
                }
            }
            groupToPatch.patchValue(msg.value, { emitEvent: false });
        }
        else {
            // Reset entire form
            this.formArrayPaths.forEach(function (path) {
                var /** @type {?} */ formArray = /** @type {?} */ (path.reduce(function (prev, property) {
                    return prev instanceof FormGroup ? prev.controls[property] : prev;
                }, /** @type {?} */ (_this.formGroup)));
                var /** @type {?} */ rows = path.reduce(function (prev, property) { return prev ? prev[property] : null; }, msg.value);
                if (rows) {
                    // Array has values
                    if (!(rows instanceof Array)) {
                        // Convert to array
                        rows = Object.keys(rows).sort().map(function (k) { return rows[k]; });
                    }
                    rows.forEach(function (row, ndx) {
                        _this.addRowToFormArray(formArray, row);
                    });
                }
            });
            this.formGroup.reset(msg.value, { emitEvent: false });
        }
    };
    /**
     * @param {?=} control
     * @param {?=} path
     * @return {?}
     */
    ReactiveFormAssistant.prototype.controlsubscribe = /**
     * @param {?=} control
     * @param {?=} path
     * @return {?}
     */
    function (control, path) {
        var _this = this;
        if (control === void 0) { control = this.formGroup; }
        if (path === void 0) { path = []; }
        if (control instanceof FormGroup) {
            Object.keys(control.controls).forEach(function (controlkey) {
                path.push(controlkey);
                _this.controlsubscribe(control.controls[controlkey], path.slice());
                path.pop();
            });
        }
        else if (control instanceof FormArray) {
            this.formArrayPaths.push(path);
            control.controls.forEach(function (arrctrl, ndx) {
                path.push("" + ndx);
                _this.controlsubscribe(arrctrl, path);
                path.pop();
            });
        }
        else if (control instanceof FormControl) {
            control.valueChanges
                .subscribe(function (val) {
                return _this.formUpdatesSubject.next(new FormUpdateEvent(path, val));
            });
        }
    };
    ReactiveFormAssistant.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    ReactiveFormAssistant.ctorParameters = function () { return [
        { type: FormBuilder, },
    ]; };
    return ReactiveFormAssistant;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */

export { CanvasTableComponent, CanvasTableContainerComponent, AnimationFrameThrottler, CanvasTableModule, FormUpdateEvent, ReactiveFormAssistant };
