import { AfterViewInit, Renderer, ElementRef, DoCheck, NgZone, EventEmitter, OnInit } from '@angular/core';
import { MatTooltip } from '@angular/material';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
export declare class AnimationFrameThrottler {
    private taskkey;
    private task;
    static taskMap: {
        [key: string]: Function;
    };
    static hasChanges: boolean;
    static mainLoop(): void;
    constructor(taskkey: string, task: Function);
}
export interface CanvasTableSelectListener {
    rowSelected(rowIndex: number, colIndex: number, rowContent: any, multiSelect?: boolean): void;
    isSelectedRow(rowObj: any): boolean;
    isBoldRow(rowObj: any): boolean;
}
export interface CanvasTableColumn {
    name: string;
    columnSectionName?: string;
    footerText?: string;
    footerSumReduce?(prev: number, curr: number): number;
    width: number;
    backgroundColor?: string;
    tooltipText?: string;
    sortColumn: number;
    excelCellAttributes?: any;
    rowWrapModeHidden?: boolean;
    rowWrapModeMuted?: boolean;
    rowWrapModeChipCounter?: boolean;
    checkbox?: boolean;
    textAlign?: number;
    compareValue?: (a: any, b: any) => number;
    getValue(rowobj: any): any;
    setValue?: (rowobj: any, val: any) => void;
    getFormattedValue?(val: any): string;
}
export declare class FloatingTooltip {
    top: number;
    left: number;
    width: number;
    height: number;
    tooltipText: string;
    constructor(top: number, left: number, width: number, height: number, tooltipText: string);
}
export declare class CanvasTableColumnSection {
    columnSectionName: string;
    width: number;
    leftPos: number;
    backgroundColor: string;
    constructor(columnSectionName: string, width: number, leftPos: number, backgroundColor: string);
}
export declare class CanvasTableComponent implements AfterViewInit, DoCheck {
    private renderer;
    private _ngZone;
    static incrementalId: number;
    elementId: string;
    private _topindex;
    topindex: number;
    canvRef: ElementRef;
    columnOverlay: MatTooltip;
    private canv;
    private ctx;
    private _rowheight;
    private fontheight;
    fontFamily: string;
    private maxVisibleRows;
    private scrollBarRect;
    private touchdownxy;
    private scrollbardrag;
    _horizScroll: number;
    horizScroll: number;
    _rows: any[];
    _columns: CanvasTableColumn[];
    columns: CanvasTableColumn[];
    hoverRowColor: string;
    selectedRowColor: string;
    colpaddingleft: number;
    colpaddingright: number;
    seprectextraverticalpadding: number;
    private lastMouseDownEvent;
    private _hoverRowIndex;
    private hoverRowIndex;
    autoRowWrapModeWidth: number;
    rowWrapMode: boolean;
    rowWrapModeWrapColumn: number;
    hasChanges: boolean;
    private formattedValueCache;
    columnSections: CanvasTableColumnSection[];
    scrollLimitHit: BehaviorSubject<number>;
    floatingTooltip: FloatingTooltip;
    selectListener: CanvasTableSelectListener;
    touchscroll: EventEmitter<{}>;
    constructor(elementRef: ElementRef, renderer: Renderer, _ngZone: NgZone);
    ngDoCheck(): void;
    ngAfterViewInit(): void;
    dragColumnOverlay(event: DragEvent): void;
    columnOverlayClicked(event: MouseEvent): void;
    doScrollBarDrag(clientY: number): void;
    getColIndexByClientX(clientX: number): number;
    selectRow(clientX: number, clientY: number, multiSelect?: boolean): void;
    scrollTop(): void;
    rows: any[];
    calculateColumnFooterSums(): void;
    recalculateColumnSections(): void;
    private enforceScrollLimit();
    /**
     * Draws a rounded rectangle using the current state of the canvas.
     * If you omit the last three params, it will draw a rectangle
     * outline with a 5 pixel border radius
     * @param ctx
     * @param x The top left x coordinate
     * @param y The top left y coordinate
     * @param width The width of the rectangle
     * @param height The height of the rectangle
     * @param [radius = 5] The corner radius; It can also be an object
     *                 to specify different radii for corners
     * @param [radius.tl = 0] Top left
     * @param [radius.tr = 0] Top right
     * @param [radius.br = 0] Bottom right
     * @param [radius.bl = 0] Bottom left
     * @param [fill = false] Whether to fill the rectangle.
     * @param [stroke = true] Whether to stroke the rectangle.
     */
    private roundRect(ctx, x, y, width, height, radius?, fill?, stroke?);
    rowheight: number;
    private dopaint();
}
export declare class CanvasTableContainerComponent implements OnInit {
    private renderer;
    colResizePreviousX: number;
    colResizeColumnIndex: number;
    columnResized: boolean;
    sortColumn: number;
    sortDescending: boolean;
    savedColumnWidths: number[];
    canvastable: CanvasTableComponent;
    configname: string;
    canvastableselectlistener: CanvasTableSelectListener;
    sortToggled: EventEmitter<any>;
    constructor(renderer: Renderer);
    ngOnInit(): void;
    colresizestart(clientX: number, colIndex: number): void;
    colresize(clientX: number): void;
    sumWidthsBefore(colIndex: number): number;
    getSavedColumnWidth(colIndex: number, defaultWidth: number): number;
    saveColumnWidths(): void;
    colresizeend(): void;
    horizScroll(evt: any): void;
    toggleSort(column: number): void;
}
