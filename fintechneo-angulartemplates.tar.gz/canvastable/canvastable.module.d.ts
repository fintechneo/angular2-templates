export { CanvasTableColumn, CanvasTableComponent, CanvasTableContainerComponent, CanvasTableSelectListener, AnimationFrameThrottler } from './canvastable.component';
export declare class CanvasTableModule {
}
