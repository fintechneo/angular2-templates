/*
 *  Copyright 2010-2016 FinTech Neo AS ( fintechneo.com )- All rights reserved
 */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTooltipModule, MatIconModule } from '@angular/material';
import { CanvasTableComponent, CanvasTableContainerComponent } from './canvastable.component';
export { CanvasTableComponent, CanvasTableContainerComponent, AnimationFrameThrottler } from './canvastable.component';
var CanvasTableModule = /** @class */ (function () {
    function CanvasTableModule() {
    }
    CanvasTableModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        MatTooltipModule,
                        MatIconModule
                    ],
                    declarations: [CanvasTableComponent, CanvasTableContainerComponent],
                    exports: [CanvasTableComponent, CanvasTableContainerComponent]
                },] },
    ];
    /**
     * @nocollapse
     */
    CanvasTableModule.ctorParameters = function () { return []; };
    return CanvasTableModule;
}());
export { CanvasTableModule };
function CanvasTableModule_tsickle_Closure_declarations() {
    /** @type {?} */
    CanvasTableModule.decorators;
    /**
     * @nocollapse
     * @type {?}
     */
    CanvasTableModule.ctorParameters;
}
//# sourceMappingURL=canvastable.module.js.map