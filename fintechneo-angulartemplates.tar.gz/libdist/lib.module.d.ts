export * from './canvastable/canvastable.module';
